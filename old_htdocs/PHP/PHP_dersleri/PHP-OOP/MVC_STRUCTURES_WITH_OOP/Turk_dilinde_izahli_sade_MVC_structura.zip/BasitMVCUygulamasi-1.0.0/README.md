# BasitMVCUygulamasi
Yazı dizisi için geliştirilen ufak bir uygulama

## Kurulum
```
git clone https://github.com/yidemir/BasitMVCUygulamasi.git
```

## Ayarlamalar
`index.php` içerisinde bulunan sabitlerden ayarlamalar yapılabilir.
